package br.com.aeroporto.controller;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class ThreadAviao extends Thread {

	private int numeroAviao;
	private static Boolean pistaNorte = true;
	private static Boolean pistaSul = true;
	private Semaphore semaforo;

	public ThreadAviao(int numeroAviao, Semaphore semaforo) {

		this.numeroAviao = numeroAviao;
		this.semaforo = semaforo;
	}

	@Override
	// Torre de controle
	public void run() {

		// -------------------- P (Acquire)----
		try {
			semaforo.acquire();
			if (pistaNorte == false) {
				pistaSul();
			} else {
				pistaNorte();
			}
			;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// ------------- V (Release)----------
			semaforo.release();
		}
	}

	private void pistaNorte() {
		pistaNorte = false;
		System.out.println("Aviao nº" + numeroAviao + "ocupou a pista Norte");
		decolagem();
		pistaNorte = true;
		System.out.println("Aviao nº" + numeroAviao + "liberou a pista Norte");

	}

	private void pistaSul() {
		pistaSul = false;
		System.out.println("Aviao nº" + numeroAviao + " ocupou a pista Sul");
		decolagem();
		pistaSul = true;
		System.out.println("Aviao nº" + numeroAviao + " liberou a pista Sul");
	}

	private void decolagem() {
		manobrar();
		taxiar();
		decolar();
		afastar();
	}

	public void manobrar() {
		try {
			int tempo = intevaloTempo(3, 7);

			sleep(tempo * 1000);
			System.out.println("O avião n°" + numeroAviao + " manobrou e levou " + tempo + "s para isso");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void taxiar() {
		try {
			int tempo = intevaloTempo(5, 10);

			sleep(tempo * 1000);
			System.out.println("O avião n°" + numeroAviao + " taxiou e levou " + tempo + "s para isso");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void decolar() {
		try {

			int tempo = intevaloTempo(1, 4);

			sleep(tempo * 1000);
			System.out.println("O avião n°" + numeroAviao + " decolou e levou " + tempo + "s para isso");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void afastar() {
		try {
			int tempo = intevaloTempo(3, 8);
			sleep(tempo * 1000);
			System.out.println("O avião n°" + numeroAviao + " afastou e levou " + tempo + "s para isso");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private int intevaloTempo(int de, int ate) {
		Random r = new Random();

		return r.nextInt(ate - de) + de;
	}
}
