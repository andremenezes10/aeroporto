package br.com.aeroporto.main;

import java.util.concurrent.Semaphore;

import br.com.aeroporto.controller.ThreadAviao;

public class Main {
	public static void main(String[] args) {
		
		int permissoes =2;
		
		Semaphore semaforo = new Semaphore(permissoes);
		
		for (int numeroAviao = 1; numeroAviao <= 12 ; numeroAviao++) {
			Thread tAviao = new ThreadAviao(numeroAviao, semaforo);
			tAviao.start();
		}
	}
}
